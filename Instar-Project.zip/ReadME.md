## Instar-Projcet 한 줄 소개
인스타그램 카피 프로젝트 Github 저장소입니다.  

## Skills  
React, React Native, Express Module, Prisma  

## History  
2022-01-07 Instar-Projcet Github 저장소 생성  
2022-01-08 GraphQL Server 구축  
2022-01-09 Apollo Server 구축  
2022-01-17 Babal 설치 및 적용  
2022-01-19 Prisma 세팅